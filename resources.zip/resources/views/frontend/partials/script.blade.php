<script src="{{ asset('frontend') }}/assets/js/vendor/jquery-3.6.0.min.js"></script>
<script src="{{ asset('frontend') }}/assets/js/swiper-bundle.min.js"></script>
<script src="{{ asset('frontend') }}/assets/js/bootstrap.min.js"></script>
<script src="{{ asset('frontend') }}/assets/js/jquery.magnific-popup.min.js"></script>
<script src="{{ asset('frontend') }}/assets/js/jquery.counterup.min.js"></script>
<script src="{{ asset('frontend') }}/assets/js/jquery-ui.min.js"></script>
<script src="{{ asset('frontend') }}/assets/js/imagesloaded.pkgd.min.js"></script>
<script src="{{ asset('frontend') }}/assets/js/isotope.pkgd.min.js"></script>
<script src="{{ asset('frontend') }}/assets/js/nice-select.min.js"></script>
<script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
<script src="{{ asset('frontend') }}/assets/js/main.js"></script>

@stack('script')
